def greeting_A():
    print('Hoe gaan dit?')
