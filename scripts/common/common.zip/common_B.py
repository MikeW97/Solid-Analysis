def greeting_B():
    print('Hoe gaan dit, meneer?')
